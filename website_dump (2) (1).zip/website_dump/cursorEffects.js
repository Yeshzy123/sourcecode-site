<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wya.lol | 404 not found</title>
    <link rel="stylesheet" type="text/css" href="/public/src/css/style.css">
    <link rel="icon" href="/public/src/img/wyableh.png">
    <meta content="wya.lol | the best bio site" property="og:title" />
    <meta content="just a 404 page, why would you even search that" property="og:description" />
    <meta content="https://wya.lol/404" property="og:url" />
    <meta content="https://cdn.discordapp.com/attachments/948551582633578498/958781091332911114/2756d134eb7b5c54ff086b9d3c310fa6.gif" property="og:thumbnail" />
    <meta content="#C18be0" data-react-helmet="true" name="theme-color" />
</head>

<body>
    <div class="main-page">
        <div class="landingAvailable">
            <h1 class="highlight2" style="margin-bottom: 2vh;">404</h1>

            <div class="landingAvailableText">
                this username is available.<br>
                <span style="font-weight: 500;">claim this username by making a ticket.</span>
            </div>
            
            <div class="usernameAvailableBox" onclick="window.open('https://discord.gg/wyalol', '_blank')">
                claim
            </div>
            
            <a href="https://wya.lol" class="notfoundminitext">main page</a>
        </div>
    </div>
</body>

</html>
